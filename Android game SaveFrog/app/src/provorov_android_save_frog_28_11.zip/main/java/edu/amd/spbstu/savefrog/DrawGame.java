package edu.amd.spbstu.savefrog;

import android.app.Activity;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.CountDownTimer;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import static edu.amd.spbstu.savefrog.MainActivity.LAYOUT_GAME_OVER;
import static edu.amd.spbstu.savefrog.R.id.timeView;

public class DrawGame extends View {
    MainActivity activity;
    Paint paint;
    Path[] path;

    FrogGame game;
    int level;
    int maxPathCount = 10;
    int score = 0;

    CountDownTimer timer;

    public DrawGame(final MainActivity activity, int level) {
        super(activity);
        this.activity = activity;
        this.level = level;
        this.score = 0;
        paint = new Paint();
        paint.setStrokeWidth(3);
        paint.setStyle(Paint.Style.FILL);
        path = new Path[maxPathCount];
        for (int i = 0; i < maxPathCount; i++) {
            path[i] = new Path();
        }
        game = new FrogGame();

        final TextView levelView = (TextView) activity.findViewById(R.id.levelview);
        Resources res = getResources();
        String str_level = String.format(res.getString(R.string.str_level), level + 1);
        levelView.setText(str_level);

        final TextView scoreView = (TextView) activity.findViewById(R.id.scoreView);
        String str_score = String.format(res.getString(R.string.str_score), score);
        scoreView.setText(str_score);

        timer = new CountDownTimer(10000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                String time = "Time: " + millisUntilFinished / 1000;
                final TextView timeView = (TextView) activity.findViewById(R.id.timeView);
                timeView.setText("" + millisUntilFinished / 1000);
                //timeView.setText("Time: " + (millisUntilFinished));
                //Resources res = getResources();
                //String str_time = String.format(res.getString(R.string.str_time), millisUntilFinished / 1000);
                //timeView.setText(str_time);
            }

            @Override
            public void onFinish() {
                activity.setCurLayout(LAYOUT_GAME_OVER);
            }
        };
        timer.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        V2d canvasSize = new V2d(canvas.getWidth(), canvas.getHeight());
        int width = canvas.getWidth();
        int height = canvas.getHeight();

        if (!game.isBuilt) {
            game.BuildGame().createLevel(level, canvasSize, BitmapFactory.decodeResource(getResources(), R.drawable.water_flower_red));
            V2d startHeroPos = new V2d(game.curLevel.leafs[0].x, game.curLevel.leafs[0].y);
            game.createHero(startHeroPos, BitmapFactory.decodeResource(getResources(), R.drawable.round_hero_2_64));
            //game.hero.pos.x = game.curLevel.leafs[0].x;
            //game.hero.pos.y = game.curLevel.leafs[0].y;
            game.hero.pos.x -= game.hero.bitmap.getWidth() / 2;
            game.hero.pos.y -= game.hero.bitmap.getHeight() / 2;
        }

        canvas.drawColor(getResources().getColor(R.color.colorWater));
        for (int i = 0; i < game.curLevel.leafCount; i++) {
            paint.setColor(getResources().getColor(R.color.colorGreen));
            if (i > 0 && i < game.curLevel.leafCount - 1) {
                if (game.curLevel.leafGrowth[i] == game.curLevel.GROW_DOWN) {
                    game.curLevel.leafSizes[i] -= 0.2;
                } else {
                    game.curLevel.leafSizes[i] += 0.2;
                }
                game.curLevel.changeGrowthIfNeed(i);
            }

            path[i].reset();
            int rad = (int) game.curLevel.leafSizes[i];
            int x = game.curLevel.leafs[i].x;
            int y = game.curLevel.leafs[i].y;
            RectF rectF = new RectF(x - rad, y - rad, x + rad, y + rad);
            //path[i].addArc(rectF, 200, 300);
            path[i].addCircle(x, y, rad, Path.Direction.CCW);
            canvas.drawPath(path[i], paint);
            if (i < game.curLevel.leafCount - 1) {
                paint.setColor(getResources().getColor(R.color.colorLeaf));
            } else {
                paint.setColor(getResources().getColor(R.color.colorAccent));
            }
            canvas.drawArc(rectF, 200, 310, true, paint);
        }

        if (game.hero.isMoving == true) {
            game.hero.moving();
        } else {
            int gameStatus = game.checkEndOfGame(game.hero.pos);
            if(gameStatus != FrogGame.GAME_STATUS_PLAY)
                drawEndOfGame(gameStatus);
        }

        canvas.drawBitmap(game.hero.bitmap, game.hero.pos.x, game.hero.pos.y, null);
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            float x = event.getX();
            float y = event.getY();
            for (Path curPath : path) {
                RectF pathBounds = new RectF();
                curPath.computeBounds(pathBounds, true);
                if (pathBounds.contains(x, y)) {
                    game.hero.moveTo(new V2d((int) x, (int) y));
                    break;
                }
            }
            invalidate();
        }
        return true;
    }

    public void drawEndOfGame(int gameStatus) {
        Resources res = getResources();
        TextView gameOverView = (TextView) activity.findViewById(R.id.gameWinText);
        String str_game_over_text = "";
        switch (gameStatus) {
            case FrogGame.GAME_STATUS_LOSE:
                timer.cancel();
                activity.setCurLayout(LAYOUT_GAME_OVER);
                gameOverView = (TextView) activity.findViewById(R.id.gameLoseText);
                str_game_over_text = res.getString(R.string.str_lose);
                break;
            case FrogGame.GAME_STATUS_WIN:
                timer.cancel();
                score += 10;
                activity.setCurLayout(MainActivity.LAYOUT_GAME_WIN);
                gameOverView = (TextView) activity.findViewById(R.id.gameWinText);
                str_game_over_text = res.getString(R.string.str_win);

                TextView finalSCore = (TextView) activity.findViewById(R.id.finalScore);
                String str_final_score = String.format(res.getString(R.string.str_score), score);
                finalSCore.setText(str_final_score);
                break;
        }
        gameOverView.setText(str_game_over_text);
    }

    public int getScore() {
        return score;
    }

    public void exitGame() {
        timer.cancel();
    }

    //public void moveHero()
}
