package edu.amd.spbstu.savefrog;

import android.graphics.Bitmap;

public class FrogGame {
    public static final int GAME_STATUS_PLAY = 1;
    public static final int GAME_STATUS_WIN  = 2;
    public static final int GAME_STATUS_LOSE = 3;
    int width, height;
    int maxDist;
    boolean isBuilt = false;
    Levels curLevel;
    Hero hero;

    public FrogGame() {
    }

    public FrogGame BuildGame() {
        //this.curLevel = new Levels(1);
        this.hero = new Hero();
        this.isBuilt = true;
        return this;
    }

    public FrogGame createLevel(int level, V2d canvasSize, Bitmap finishLeaf) {
        width = canvasSize.x;
        height = canvasSize.y;
        maxDist = width / 2;
        this.curLevel = new Levels(level, finishLeaf);
        return this;
    }

    public static int distance(V2d p1, V2d p2) {
        return (int) Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
    }

    public FrogGame createHero(V2d startPos, Bitmap hero) {
        this.hero.createHero(startPos, hero);
        return this;
    }

    class Hero {
        V2d pos;
        Bitmap bitmap;
        boolean isMoving = false;
        V2d moveTo;
        V2d moveFrom;
        private float lambda = 0;

        public Hero() {
        }

        public void createHero(V2d startPos, Bitmap hero) {
            this.pos = startPos;
            this.bitmap = hero;
        }

        public void setPos(V2d pos) {
            this.pos = pos;
        }

        public void moveTo(V2d pos) {
            isMoving = true;
            moveTo = pos;
            moveTo.x -= hero.bitmap.getWidth() / 2;
            moveTo.y -= hero.bitmap.getHeight() / 2;
            moveFrom = new V2d(this.pos.x, this.pos.y);
        }

        public void moving() {
            if (lambda < 1f && distance(moveFrom, pos) < maxDist) {
                pos.x = (int) ((1 - lambda) * moveFrom.x + lambda * moveTo.x);
                pos.y = (int) ((1 - lambda) * moveFrom.y + lambda * moveTo.y);
                lambda += 0.01;
            } else {
                lambda = 0;
                isMoving = false;
            }
        }
    }

    class Levels {
        public static final int LEVEL_FIRST = 1;
        public static final int LEVEL_SECOND = 2;
        public static final int LEVEL_THIRD = 3;
        public static final int LEVEL_FOURTH = 4;
        public static final int LEAF_SIZE = 80;
        public static final int LEAF_SIZE_MIN = 30;
        public static final int LEAF_SIZE_MAX = 90;
        public static final int GROW_UP = 1;
        public static final int GROW_DOWN = 0;

        int leafCount = 4;
        V2d[] leafs = new V2d[leafCount];
        float[] leafSizes = new float[leafCount];
        int[] leafGrowth = new int[leafCount];
        Bitmap finishLeaf;
        int curLevel;

        public Levels(int curLevel, Bitmap finishLeaf) {
            this.finishLeaf = finishLeaf;
            for (int i = 0; i < leafCount; i++) {
                leafs[i] = new V2d();
                leafSizes[i] = LEAF_SIZE;
                if(i % 2 == 0) {
                    leafGrowth[i] = GROW_UP;
                } else {
                    leafGrowth[i] = GROW_DOWN;
                }
            }

            if (!(curLevel <= 0 || curLevel > 4)) {
                this.curLevel = curLevel;
            } else {
                curLevel = LEVEL_FIRST;
            }
            switch (curLevel) {
                case 1:
                    leafs[0].x = width / 6;
                    leafs[0].y = height / 4;
                    leafs[1].x = width / 3;
                    leafs[1].y = height * 3 / 4;
                    leafs[2].x = width * 4 / 7;
                    leafs[2].y = height / 4;
                    leafs[3].x = width * 5 / 6;
                    leafs[3].y = height / 2;
                    break;
            }
        }

        public void setLeafSize(int i, int size) {
            leafSizes[i] = size;
        }

        public void changeGrowthIfNeed(int i) {
            if(leafSizes[i] < LEAF_SIZE_MIN) {
                leafGrowth[i] = GROW_UP;
                return;
            }
            if(leafSizes[i] > LEAF_SIZE_MAX) {
                leafGrowth[i] = GROW_DOWN;
                return;
            }
        }

        boolean isWin(V2d pos) {
            if((Math.abs(pos.x - leafs[leafCount - 1].x) <= LEAF_SIZE * 2) && (Math.abs(pos.y - leafs[leafCount - 1].y) <= LEAF_SIZE * 2))
                return true;
            return false;
        }

        int isGameOver(V2d pos) {
            if (isWin(pos) == true)
                return GAME_STATUS_WIN;

            for (int i = 0; i < leafCount; i++) {
                if((Math.abs(pos.x - leafs[i].x) <= LEAF_SIZE * 2) && (Math.abs(pos.y - leafs[i].y) <= LEAF_SIZE * 2))
                    if(leafSizes[i] >= LEAF_SIZE_MIN) {
                        return GAME_STATUS_PLAY;
                    } else {
                        return GAME_STATUS_LOSE;
                    }
            }
            return GAME_STATUS_LOSE;
        }
    }
}
