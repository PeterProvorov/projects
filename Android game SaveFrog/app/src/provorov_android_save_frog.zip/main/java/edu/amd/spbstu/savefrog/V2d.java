package edu.amd.spbstu.savefrog;

public class V2d {
    public int x;
    public int y;

    public V2d() {
    }

    public V2d(int x, int y) {
        this.x = x;
        this.y = y;
    }
};
