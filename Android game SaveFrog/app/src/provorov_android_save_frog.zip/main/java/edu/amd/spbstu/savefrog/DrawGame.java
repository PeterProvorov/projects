package edu.amd.spbstu.savefrog;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.CountDownTimer;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DrawGame extends View {
    Activity activity;
    Paint paint;
    Path[] path;

    FrogGame game;
    int level;
    int maxPathCount = 10;

    TextView timeText;

    public DrawGame(Activity activity, int level) {
        super(activity);
        this.activity = activity;
        this.level = level;
        paint = new Paint();
        paint.setStrokeWidth(3);
        paint.setStyle(Paint.Style.FILL);
        path = new Path[maxPathCount];
        for (int i = 0; i < maxPathCount; i++) {
            path[i] = new Path();
        }
        game = new FrogGame();
        timeText = new TextView(activity);
        timeText.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        V2d canvasSize = new V2d(canvas.getWidth(), canvas.getHeight());
        int width = canvas.getWidth();
        int height = canvas.getHeight();

        if(!game.isBuilt) {
            CountDownTimer timer = new CountDownTimer(30000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    timeText.setText("Time: " + (millisUntilFinished / 1000));
                }

                @Override
                public void onFinish() {
                    activity.setContentView(R.layout.game_lose);
                }
            };
            timer.start();
            game.BuildGame().createLevel(level, canvasSize, BitmapFactory.decodeResource(getResources(), R.drawable.water_flower_red));
            V2d startHeroPos = new V2d(game.curLevel.leafs[0].x, game.curLevel.leafs[0].y);
            game.createHero(startHeroPos, BitmapFactory.decodeResource(getResources(), R.drawable.round_hero_2_64));
            game.hero.pos.x -= game.hero.bitmap.getWidth() / 2;
            game.hero.pos.y -= game.hero.bitmap.getHeight() / 2;
        }

        canvas.drawColor(getResources().getColor(R.color.colorWater));
        paint.setColor(getResources().getColor(R.color.colorLeaf));
        for (int i = 0; i < game.curLevel.leafCount; i++) {
            if(i == game.curLevel.leafCount - 1) {
                paint.setColor(getResources().getColor(R.color.colorAccent));
            } else {
                if(i > 0) {
                    if (game.curLevel.leafGrowth[i] == game.curLevel.GROW_DOWN) {
                        game.curLevel.leafSizes[i] -= 0.2;
                    } else {
                        game.curLevel.leafSizes[i] += 0.2;
                    }
                    game.curLevel.changeGrowthIfNeed(i);
                }
            }
            path[i].reset();
            path[i].addCircle(game.curLevel.leafs[i].x, game.curLevel.leafs[i].y, (int)game.curLevel.leafSizes[i], Path.Direction.CCW);
            canvas.drawPath(path[i], paint);
        }

        if(game.hero.isMoving == true) {
            game.hero.moving();
        } else {
            int gameStatus = game.curLevel.isGameOver(game.hero.pos);
            if(gameStatus == FrogGame.GAME_STATUS_LOSE) {
                activity.setContentView(R.layout.game_lose);
            } else if (gameStatus == FrogGame.GAME_STATUS_WIN) {
                activity.setContentView(R.layout.game_win);
            }
        }

        canvas.drawBitmap(game.hero.bitmap, game.hero.pos.x, game.hero.pos.y, null);
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN) {
            float x = event.getX();
            float y = event.getY();
            for (Path curPath: path) {
                RectF pathBounds = new RectF();
                curPath.computeBounds(pathBounds,true);
                if(pathBounds.contains(x,y)) {
                    game.hero.moveTo(new V2d((int)x, (int)y));
                    break;
                }
            }
            invalidate();
        }
        return true;
    }

    //public void moveHero()
}
